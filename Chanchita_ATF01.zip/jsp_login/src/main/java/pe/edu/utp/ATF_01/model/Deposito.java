package pe.edu.utp.ATF_01.model;
import java.time.LocalDateTime;

public class Deposito {
    private String numero_Cuenta;
    private LocalDateTime fechaHora;
    private String nombrePersona;
    private double monto;
    private String detalle;
}
