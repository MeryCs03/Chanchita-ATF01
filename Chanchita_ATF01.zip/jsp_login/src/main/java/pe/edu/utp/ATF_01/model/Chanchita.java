package pe.edu.utp.ATF_01.model;

public class Chanchita {
    private String nombre;
    private String numerocuenta;
}
