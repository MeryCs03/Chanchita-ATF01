package pe.edu.utp.ATF_01.model;

public class Usuario {
    private String nombre;
    private String apellido;
    private String correo;
    private String contrasena;
}
